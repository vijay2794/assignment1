package arrayrandom;

import java.util.Random;
import java.util.Scanner;

public class ArrayRandom {

    public static void main(String[] args) {
        int randarray ;
        int num;
        int seno;
        int elementFound = -1;
        Random randno = new Random();
        Scanner scan = new Scanner(System.in);

        System.out.print("How many elements?  ");
        num = scan.nextInt();

        int[] array = new int[num];
        for (int i = 0; i < num; i++) {
            array[i] = randno.nextInt(999);
                        System.out.println((i+1) + ": " + array[i]);

        }
        System.out.println("Random numbers are:");
        
        System.out.print("Which no to search? ");
        seno = scan.nextInt();
        for (int j = 0; j < num; j++) {
            if (array[j] == seno) {
                elementFound = j;

            }

        }
        if (elementFound == -1) {
            System.out.println("value not found");
        } else {
            System.out.println("Element found at index: " +( elementFound+1) );
        }
    }

}
